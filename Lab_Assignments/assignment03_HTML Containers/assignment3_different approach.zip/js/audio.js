// Data for the "HTML Audio" Page

var audio = {
    controls: false, 
    source: [
        {src: "https://scs.senecac.on.ca/~tanvir.alam/shared/fall-2018/web222/Track03.mp3", type: "audio/mpeg"},
        {src: "https://scs.senecac.on.ca/~tanvir.alam/shared/fall-2018/web222/Track03.ogg", type: "audio/ogg"}
    ]
};


window.onload = function(){
    var myAudio = document.querySelector("#audioTag");

    innerAudio = "";
    audio.source.forEach(function(element){
        innerAudio += `<source src = ${element.src} type = ${element.type} />`
    });
    innerAudio += "Your browser does not support the audio tag used.";

    if(audio.controls){
        myAudio.innerHTML += `<figure><audio controls autoplay> ${innerAudio} </audio></figure>`;
    }else{
        myAudio.innerHTML += `<figure><audio autoplay> ${innerAudio} </audio></figure>`;
    }
}