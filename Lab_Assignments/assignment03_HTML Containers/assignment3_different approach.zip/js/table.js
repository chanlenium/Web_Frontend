// Data for the "HTML Tables" Page

var users = [
  {
    first_name: "Kaitlin",
    last_name: "Burns",
    age: 23,
    email: "kburns99753@usermail.com",
  },
  {
    first_name: "Joshua",
    last_name: "Feir",
    age: 31,
    email: "josh319726@usermail.com",
  },
  {
    first_name: "Stephen",
    last_name: "Shaw",
    age: 28,
    email: "steve.shaw47628@usermail.com",
  },
  {
    first_name: "Timothy",
    last_name: "McAlpine",
    age: 37,
    email: "Timbo72469@usermail.com",
  },
  {
    first_name: "Sarah",
    last_name: "Connor",
    age: 19,
    email: "SarahC6320@usermail.com",
  },
];


window.onload = function () {
  var myTable = document.querySelector("#userTable");

  var myTableHeader = "";
  myTableHeader += `<thead>
      <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Age</th>
        <th>Email</th>
      </tr>
    </thead>`;

  var myTableBody = "";
  users.forEach(function (userInfo) {
    myTableBody += `<tr><td>${userInfo.first_name}</td>
	    			<td>${userInfo.last_name}</td>
	    				 <td>${userInfo.age}</td>
	    				 <td><a href="mailto:user.email">${userInfo.email}</a></td></tr>`;
  });

  console.log("<table>" + myTableHeader + myTableBody + "</table>");

  myTable.innerHTML += "<table>" + myTableHeader + myTableBody + "</table>";
};
