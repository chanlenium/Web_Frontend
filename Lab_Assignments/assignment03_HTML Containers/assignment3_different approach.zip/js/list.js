// Data for the "HTML Lists" Page

var fruits = ["Apples", "Oranges", "Pears", "Grapes", "Pineapples", "Mangos"];

var directory = [
  { type: "file", name: "file1.txt" },
  { type: "file", name: "file2.txt" },
  {
    type: "directory",
    name: "HTML Files",
    files: [
      { type: "file", name: "file1.html" },
      { type: "file", name: "file2.html" },
    ],
  },
  { type: "file", name: "file3.txt" },
  {
    type: "directory",
    name: "JavaScript Files",
    files: [
      { type: "file", name: "file1.js" },
      { type: "file", name: "file2.js" },
      { type: "file", name: "file3.js" },
    ],
  },
];

window.onload = function () {
  var fruitsList = document.querySelector("#fruits");
  var temp = "";
  fruits.forEach(function (element) {
    temp += "<li>" + element + "</li>";
  });
  fruitsList.innerHTML += "<ol>" + temp + "</ol>";

  var myDirectory = document.querySelector("#directArray");
  var inner = "";
  directory.forEach(function (element) {
    inner += "<li>" + element.name + "</li>";
    if (element.type == "directory") {
      inner += "<ul>";
      element.files.forEach(function (value) {
        inner += "<li>" + value.name + "</li>";
      });
      inner += "</ul>";
    }
  });
  myDirectory.innerHTML += "<ul>" + inner + "</ul>";
};
