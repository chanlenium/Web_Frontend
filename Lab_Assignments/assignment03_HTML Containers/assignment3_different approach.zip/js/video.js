// Data for the "HTML Video" Page

var video = {
    controls: true, 
    width: 320,
    height: 240,
    source: [
        {src: "https://scs.senecac.on.ca/~tanvir.alam/shared/fall-2018/web222/movie.mp4", type: "video/mp4"},
        {src: "https://scs.senecac.on.ca/~tanvir.alam/shared/fall-2018/web222/movie.ogg", type: "video/ogg"}
    ]
};


window.onload = function(){
    var myVideo = document.querySelector("#videoTag");
    myVideo.width = video.width;
    myVideo.height = video.height;

    innerVideo = "";
    video.source.forEach(function(element){
        innerVideo += `<source src = ${element.src} type = ${element.type} />`
    });
    innerVideo += "Your browser does not support the audio tag used.";

    if(video.controls){
        myVideo.innerHTML += `<figure>
        <video width=${myVideo.width} height=${myVideo.height} controls>
        ${innerVideo}</video></figure>`;
    }else{
        myVideo.innerHTML += `<figure>
        <video width=${myVideo.width} height=${myVideo.height}>
        ${innerVideo}</video></figure>`;
    }
    
}